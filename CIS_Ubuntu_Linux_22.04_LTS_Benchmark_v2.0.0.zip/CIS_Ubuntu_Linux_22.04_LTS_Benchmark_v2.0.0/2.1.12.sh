
# dpkg-query -s rpcbind &>/dev/null && echo "rpcbind is installed"

# systemctl is-enabled rpcbind.socket rpcbind.service 2>/dev/null | grep 'enabled'

# systemctl is-active rpcbind.socket rpcbind.service 2>/dev/null | grep '^active'
