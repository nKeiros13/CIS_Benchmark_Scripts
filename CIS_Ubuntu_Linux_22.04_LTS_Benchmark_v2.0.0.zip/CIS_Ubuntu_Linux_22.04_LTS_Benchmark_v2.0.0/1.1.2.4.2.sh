
# findmnt -kn /var | grep -v nodev