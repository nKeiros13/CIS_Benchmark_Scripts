# sshd -T | grep -Pi -- '(clientaliveinterval|clientalivecountmax)'

# sshd -T -C user=sshuser | grep -Pi -- '(clientaliveinterval|clientalivecountmax)'
