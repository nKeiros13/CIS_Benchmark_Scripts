
# findmnt -kn /var/tmp | grep -v nosuid