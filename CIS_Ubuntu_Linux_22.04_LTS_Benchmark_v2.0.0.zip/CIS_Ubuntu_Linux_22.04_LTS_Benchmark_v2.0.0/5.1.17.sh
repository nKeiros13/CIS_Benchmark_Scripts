# sshd -T | grep -i maxsessions

# grep -Psi -- '^\h*MaxSessions\h+\"?(1[1-9]|[2-9][0-9]|[1-9][0-9][0-9]+)\b' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf

# sshd -T -C user=sshuser | grep maxsessions
