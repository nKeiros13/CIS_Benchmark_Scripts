# systemctl is-enabled systemd-journald.service

# systemctl is-active systemd-journald.service
