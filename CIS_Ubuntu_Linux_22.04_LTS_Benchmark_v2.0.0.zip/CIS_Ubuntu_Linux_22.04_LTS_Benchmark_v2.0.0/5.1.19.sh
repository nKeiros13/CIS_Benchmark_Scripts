# sshd -T | grep permitemptypasswords

# sshd -T -C user=sshuser | grep permitemptypasswords
