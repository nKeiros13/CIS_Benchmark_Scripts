
# dpkg-query -s tftpd-hpa &>/dev/null && echo "tftpd-hpa is installed"

# systemctl is-enabled tftpd-hpa.service 2>/dev/null | grep 'enabled'


# systemctl is-active tftpd-hpa.service 2>/dev/null | grep '^active'
