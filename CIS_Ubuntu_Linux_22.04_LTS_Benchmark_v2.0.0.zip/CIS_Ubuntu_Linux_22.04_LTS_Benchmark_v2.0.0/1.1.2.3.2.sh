
# findmnt -kn /home | grep -v nodev
