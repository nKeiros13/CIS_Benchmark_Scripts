
# apparmor_status | grep profiles


# apparmor_status | grep processes