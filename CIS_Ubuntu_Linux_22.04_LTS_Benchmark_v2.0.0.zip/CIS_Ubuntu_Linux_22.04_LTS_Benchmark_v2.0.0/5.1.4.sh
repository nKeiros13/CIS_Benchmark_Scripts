# sshd -T | grep -Pi -- '^\h*(allow|deny)(users|groups)\h+\H+'

# sshd -T -C user=sshuser | grep -Pi -- '^\h*(allow|deny)(users|groups)\h+\H+'
