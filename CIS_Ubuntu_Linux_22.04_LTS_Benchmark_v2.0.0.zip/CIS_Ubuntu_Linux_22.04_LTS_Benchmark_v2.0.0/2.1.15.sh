
# dpkg-query -s snmpd &>/dev/null && echo "snmpd is installed"

# systemctl is-enabled snmpd.service 2>/dev/null | grep 'enabled'

# systemctl is-active snmpd.service 2>/dev/null | grep '^active'
