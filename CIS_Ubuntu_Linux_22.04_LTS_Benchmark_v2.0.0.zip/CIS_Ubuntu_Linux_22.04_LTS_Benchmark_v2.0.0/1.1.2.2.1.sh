
# findmnt -kn /dev/shm