
# dpkg-query -s squid &>/dev/null && echo "squid is installed"

# systemctl is-enabled squid.service 2>/dev/null | grep 'enabled'


# systemctl is-active squid.service 2>/dev/null | grep '^active'

