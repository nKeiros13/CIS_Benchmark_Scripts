# dpkg-query -s libpam-runtime | grep -P -- '^(Status|Version)\b'
