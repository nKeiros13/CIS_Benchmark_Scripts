
# findmnt -kn /var | grep -v nosuid