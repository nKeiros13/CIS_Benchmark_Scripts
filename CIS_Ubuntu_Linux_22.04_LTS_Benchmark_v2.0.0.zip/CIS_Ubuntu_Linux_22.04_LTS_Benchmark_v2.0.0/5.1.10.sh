# sshd -T | grep hostbasedauthentication

# sshd -T -C user=sshuser | grep hostbasedauthentication
