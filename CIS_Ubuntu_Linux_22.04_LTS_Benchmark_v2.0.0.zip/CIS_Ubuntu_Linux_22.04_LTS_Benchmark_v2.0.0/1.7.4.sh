
# gsettings get org.gnome.desktop.screensaver lock-delay

# gsettings get org.gnome.desktop.session idle-delay