
# dpkg-query -s xinetd &>/dev/null && echo "xinetd is installed"

# systemctl is-enabled xinetd.service 2>/dev/null | grep 'enabled'

# systemctl is-active xinetd.service 2>/dev/null | grep '^active'

