# grep -P -- '\bpam_faillock\.so\b' /etc/pam.d/common-{auth,account}
