
# dpkg-query -s telnet &>/dev/null && echo "telnet is installed"
