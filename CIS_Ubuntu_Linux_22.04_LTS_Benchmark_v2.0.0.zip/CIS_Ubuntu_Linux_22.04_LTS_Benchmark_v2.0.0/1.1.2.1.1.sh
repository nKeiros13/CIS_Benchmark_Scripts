
# findmnt -kn /tmp

# systemctl is-enabled tmp.mount
