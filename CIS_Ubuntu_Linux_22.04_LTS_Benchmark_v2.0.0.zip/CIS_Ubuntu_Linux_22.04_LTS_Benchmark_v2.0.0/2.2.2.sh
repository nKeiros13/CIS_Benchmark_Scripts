
# dpkg-query -s rsh-client &>/dev/null && echo "rsh-client is installed"
