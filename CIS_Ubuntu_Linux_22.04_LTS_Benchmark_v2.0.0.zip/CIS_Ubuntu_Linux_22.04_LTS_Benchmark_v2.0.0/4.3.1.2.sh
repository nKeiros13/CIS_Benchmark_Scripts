# dpkg-query -s nftables &>/dev/null && echo "nftables is installed"

