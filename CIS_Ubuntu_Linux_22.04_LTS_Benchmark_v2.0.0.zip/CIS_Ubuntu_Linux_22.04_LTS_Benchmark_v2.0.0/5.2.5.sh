# grep -r "^[^#].*\!authenticate" /etc/sudoers*
