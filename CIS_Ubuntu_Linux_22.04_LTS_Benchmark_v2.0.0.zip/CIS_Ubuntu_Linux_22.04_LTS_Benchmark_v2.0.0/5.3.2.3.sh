# grep -P -- '\bpam_pwquality\.so\b' /etc/pam.d/common-password
