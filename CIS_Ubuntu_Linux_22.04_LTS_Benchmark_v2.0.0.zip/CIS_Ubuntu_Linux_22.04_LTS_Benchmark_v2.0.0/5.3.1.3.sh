# dpkg-query -s libpam-pwquality | grep -P -- '^(Status|Version)\b'
