# sshd -T | grep permitrootlogin

# sshd -T -C user=sshuser | grep permitrootlogin
