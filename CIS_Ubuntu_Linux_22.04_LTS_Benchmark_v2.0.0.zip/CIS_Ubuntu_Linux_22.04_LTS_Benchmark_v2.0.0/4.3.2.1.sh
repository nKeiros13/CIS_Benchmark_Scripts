# iptables -L INPUT -v -n

# iptables -L OUTPUT -v -n
