# sshd -T | grep ignorerhosts

# sshd -T -C user=sshuser | grep ignorerhosts
