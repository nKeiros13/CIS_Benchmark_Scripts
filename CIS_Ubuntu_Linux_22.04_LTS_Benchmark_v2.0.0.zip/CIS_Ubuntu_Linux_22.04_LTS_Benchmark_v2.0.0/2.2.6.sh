
# dpkg-query -s ftp &>/dev/null && echo "ftp is installed"
