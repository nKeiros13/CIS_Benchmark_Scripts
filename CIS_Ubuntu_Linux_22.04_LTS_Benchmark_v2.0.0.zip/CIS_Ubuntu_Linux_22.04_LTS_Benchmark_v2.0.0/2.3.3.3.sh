
# systemctl is-enabled chrony.service


# systemctl is-active chrony.service
