#!/bin/bash

for script in *.sh; do
    # Skip this file
    if [ "$script" == "run_all.sh" ]; then
        continue
    fi

    echo "🔹 Executing file: $script"
    bash "$script"
    status=$?
    if [ $status -eq 0 ]; then
        echo "✅ $script completed successfully"
    else
        echo "❌ $script failed with exit code $status"
    fi
    echo "--------------------------------------"
done