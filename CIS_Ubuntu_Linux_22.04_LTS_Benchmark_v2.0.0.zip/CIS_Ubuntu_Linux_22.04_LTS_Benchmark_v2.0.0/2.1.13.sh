
# dpkg-query -s rsync &>/dev/null && echo "rsync is installed"

# systemctl is-enabled rsync.service 2>/dev/null | grep 'enabled'

# systemctl is-active rsync.service 2>/dev/null | grep '^active'
