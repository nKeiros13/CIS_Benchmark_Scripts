# ufw status verbose

