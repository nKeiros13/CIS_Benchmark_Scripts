
# dpkg-query -s nis &>/dev/null && echo "nis is installed"
