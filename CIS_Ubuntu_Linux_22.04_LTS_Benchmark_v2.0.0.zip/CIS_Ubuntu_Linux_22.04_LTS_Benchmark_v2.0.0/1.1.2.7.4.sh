
# findmnt -kn /var/log/audit | grep -v noexec