# grep -P -- '\bpam_unix\.so\b' /etc/pam.d/common-{account,session,auth,password}
