
# dpkg-query -s ypserv &>/dev/null && echo "ypserv is installed"

# systemctl is-enabled ypserv.service 2>/dev/null | grep 'enabled'

# systemctl is-active ypserv.service 2>/dev/null | grep '^active'