
# findmnt -kn /home | grep -v nosuid