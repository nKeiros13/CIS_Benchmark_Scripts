# sshd -T | grep -i usepam
