
# findmnt -kn /var/log | grep -v nosuid