
# dpkg-query -s bind9 &>/dev/null && echo "bind9 is installed"

# systemctl is-enabled bind9.service 2>/dev/null | grep 'enabled'

# systemctl is-active bind9.service 2>/dev/null | grep '^active'
