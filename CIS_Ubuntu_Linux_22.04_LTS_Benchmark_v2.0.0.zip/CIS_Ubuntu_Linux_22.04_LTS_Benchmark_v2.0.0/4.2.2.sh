# dpkg-query -s ufw &>/dev/null && echo "ufw is installed"
# ufw status
# systemctl is-enabled ufw.service