
# findmnt -kn /dev/shm | grep -v 'nodev'
