# grep -Pi -- '^\h*PASS_MAX_DAYS\h+\d+\b' /etc/login.defs

# awk -F: '($2~/^\$.+\$/) {if($5 > 365 || $5 < 1)print "User: " $1 " PASS_MAX_DAYS: " $5}' /etc/shadow
