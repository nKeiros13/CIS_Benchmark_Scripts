# dpkg-query -s aide &>/dev/null && echo "aide is installed"

# dpkg-query -s aide-common &>/dev/null && echo "aide-common is installed"
