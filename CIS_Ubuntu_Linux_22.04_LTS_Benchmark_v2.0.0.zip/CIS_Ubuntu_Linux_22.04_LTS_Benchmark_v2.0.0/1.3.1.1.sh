
# dpkg-query -s apparmor &>/dev/null && echo "apparmor is installed" 

# dpkg-query -s apparmor-utils &>/dev/null && echo "apparmor-utils is installed" 