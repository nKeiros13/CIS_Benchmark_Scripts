
# dpkg-query -s nfs-kernel-server &>/dev/null && echo "nfs-kernel-server is installed"

# systemctl is-enabled nfs-server.service 2>/dev/null | grep 'enabled'

# systemctl is-active nfs-server.service 2>/dev/null | grep '^active'
