
# dpkg-query -s ldap-utils &>/dev/null && echo "ldap-utils is installed"
