# sshd -T | grep permituserenvironment
