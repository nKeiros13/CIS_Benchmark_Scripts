# systemctl is-enabled systemd-journal-remote.socket systemd-journal-remote.service | grep -P -- '^enabled'

# systemctl is-active systemd-journal-remote.socket systemd-journal-remote.service | grep -P -- '^active'
