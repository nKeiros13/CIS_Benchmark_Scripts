# iptables -L
# ip6tables -L