# grep -P -- '\bpam_pwhistory\.so\b' /etc/pam.d/common-password
