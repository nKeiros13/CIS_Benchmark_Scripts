# systemctl is-enabled ufw.service

# systemctl is-active ufw

# ufw status

