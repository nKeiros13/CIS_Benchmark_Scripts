# sshd -T | grep -Pi -- '^banner\h+\/\H+'

# sshd -T -C user=sshuser | grep -Pi -- '^banner\h+\/\H+'
