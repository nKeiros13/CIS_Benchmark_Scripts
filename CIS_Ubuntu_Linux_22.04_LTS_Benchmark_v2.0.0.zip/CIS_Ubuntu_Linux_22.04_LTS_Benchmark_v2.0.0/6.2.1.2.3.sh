# systemctl is-enabled systemd-journal-upload.service

# systemctl is-active systemd-journal-upload.service
