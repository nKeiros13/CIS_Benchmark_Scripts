# dpkg-query -s systemd-journal-remote &>/dev/null && echo "systemd-journal-remote is installed"

