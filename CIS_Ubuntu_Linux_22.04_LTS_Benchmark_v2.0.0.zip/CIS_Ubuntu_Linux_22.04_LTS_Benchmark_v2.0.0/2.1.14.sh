
# dpkg-query -s samba &>/dev/null && echo "samba is installed"

# systemctl is-enabled smbd.service 2>/dev/null | grep 'enabled'

# systemctl is-active smbd.service 2>/dev/null | grep '^active'

