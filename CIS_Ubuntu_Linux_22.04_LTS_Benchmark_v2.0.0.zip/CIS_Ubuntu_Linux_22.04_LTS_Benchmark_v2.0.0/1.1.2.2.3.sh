
# findmnt -kn /dev/shm | grep -v 'nosuid'