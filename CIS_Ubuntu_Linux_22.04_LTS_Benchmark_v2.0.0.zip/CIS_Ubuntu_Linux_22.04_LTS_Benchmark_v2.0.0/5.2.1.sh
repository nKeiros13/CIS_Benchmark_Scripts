# dpkg-query -s sudo &>/dev/null && echo "sudo is installed"

# dpkg-query -s sudo-ldap &>/dev/null && echo "sudo-ldap is installed"
