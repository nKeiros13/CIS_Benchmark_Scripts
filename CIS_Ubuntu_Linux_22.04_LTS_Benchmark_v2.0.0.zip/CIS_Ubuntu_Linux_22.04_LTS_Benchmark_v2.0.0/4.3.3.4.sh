# ss -6tuln

# ip6tables -L INPUT -v -n

#!/usr/bin/bash

