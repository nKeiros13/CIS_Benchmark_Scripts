
# findmnt -kn /tmp | grep -v noexec