# nft list ruleset | grep 'hook input'

# nft list ruleset | grep 'hook forward'

# nft list ruleset | grep 'hook output'

