
# dpkg-query -s talk &>/dev/null && echo "talk is installed"
