
# dpkg-query -s dnsmasq &>/dev/null && echo "dnsmasq is installed"

# systemctl is-enabled dnsmasq.service 2>/dev/null | grep 'enabled'

# systemctl is-active dnsmasq.service 2>/dev/null | grep '^active'
