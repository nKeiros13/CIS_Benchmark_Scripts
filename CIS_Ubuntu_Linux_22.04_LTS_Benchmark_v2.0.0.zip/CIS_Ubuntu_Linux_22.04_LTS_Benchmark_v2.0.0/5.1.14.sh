# sshd -T | grep loglevel

# sshd -T -C user=sshuser | grep loglevel
