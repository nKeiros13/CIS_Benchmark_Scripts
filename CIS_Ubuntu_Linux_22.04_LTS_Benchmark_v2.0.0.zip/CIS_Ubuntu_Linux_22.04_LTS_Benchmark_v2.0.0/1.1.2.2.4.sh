
# findmnt -kn /dev/shm | grep -v 'noexec'