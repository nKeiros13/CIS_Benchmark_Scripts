
# dpkg-query -s prelink &>/dev/null && echo "prelink is installed" 
