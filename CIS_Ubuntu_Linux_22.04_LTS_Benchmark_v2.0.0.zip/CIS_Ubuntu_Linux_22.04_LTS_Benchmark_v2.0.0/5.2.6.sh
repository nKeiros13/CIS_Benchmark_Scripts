# grep -roP "timestamp_timeout=\K[0-9]*" /etc/sudoers*

# sudo -V | grep "Authentication timestamp timeout:"
