
# grep "^set superusers" /boot/grub/grub.cfg

# awk -F. '/^\s*password/ {print $1"."$2"."$3}' /boot/grub/grub.cfg
