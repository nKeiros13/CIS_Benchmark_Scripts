# dpkg-query -s libpam-modules | grep -P -- '^(Status|Version)\b'
