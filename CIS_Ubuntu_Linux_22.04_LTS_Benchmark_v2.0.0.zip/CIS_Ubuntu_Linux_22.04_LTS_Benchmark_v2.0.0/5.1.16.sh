# sshd -T | grep maxauthtries

# sshd -T -C user=sshuser | grep maxauthtries
